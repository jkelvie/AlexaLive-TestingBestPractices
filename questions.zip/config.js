module.exports = Object.freeze({
  // Alexa Skill ID
  APPID: process.env.SKILL_ID,
  // DynamoDB Table name
  TABLE_NAME: 'ClassicMovieTriviaUsers'
});
